from prompt_energy.utilisation_plan import load_config
from prompt_energy.utilisation_eval import load_dataset,score_function
from pathlib import Path
import json
root=Path("results/utilisation/validation")
tasks=load_dataset(root/"HumanEvalPlus.jsonl.gz","272720b90ac375502c8ed23cd791c2a93dfb22a911641a494da74a426c09f101")
cfg,_=load_config()
with (root/"references.jsonl").open("w") as log:
    for tid,t in tasks.items():
        try:
            r=score_function(t,t["prompt"]+t["canonical_solution"],cfg["evaluation"],1729)
        except Exception as e:
            r={"error":str(e)}
        print(json.dumps([tid,r]),file=log,flush=True)
