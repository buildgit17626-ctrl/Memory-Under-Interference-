# Supervisor checkpoint

User pause

~~~json
{
  "state": {
    "reason": "stopped",
    "started_at": "2026-11-24T06:19:30.233542+00:00",
    "sensor": "LOCAL_USER_ROOT\\Downloads\\New folder\\ver12_hwf.CSV",
    "elapsed_time_cutoff": null,
    "stage": "E4_schema",
    "phase": "full",
    "operation": "generation",
    "stop_reason": "User pause"
  },
  "counts": {
    "E4_schema/pilot": {
      "planned": 20,
      "saved": 20,
      "valid": 20,
      "energy_available": 20,
      "output_64": 20,
      "setup_HTTP_requests": 152
    },
    "E4_schema/full": {
      "planned": 400,
      "saved": 76,
      "valid": 76,
      "energy_available": 76,
      "output_64": 76,
      "setup_HTTP_requests": 587
    },
    "E3/pilot": {
      "saved": 0,
      "maximum": 130
    }
  },
  "details": {
    "schedule_hash": "1295b261a07feff039bdf10b0a07b5da40593378ac1fa66888a5e37e330bc30d",
    "planned": 400,
    "completed": 76,
    "remaining": 324,
    "reason": "user_pause",
    "elapsed_time_cutoff": null
  }
}
~~~
