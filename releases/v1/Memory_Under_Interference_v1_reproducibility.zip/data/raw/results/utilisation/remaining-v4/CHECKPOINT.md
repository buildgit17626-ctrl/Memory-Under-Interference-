# Supervisor checkpoint

E4 cache/residency/workload validity failed; retain output and inspect

~~~json
{
  "state": {
    "reason": "stopped",
    "started_at": "2026-11-23T19:22:54.155674+00:00",
    "sensor": "LOCAL_USER_ROOT\\Downloads\\New folder\\ver11_hwf.CSV",
    "elapsed_time_cutoff": null,
    "stage": "E4",
    "phase": "pilot",
    "operation": "generation",
    "stop_reason": "E4 cache/residency/workload validity failed; retain output and inspect"
  },
  "inventory": {
    "M2/pilot": {
      "calls": 50,
      "scores": 50,
      "input_invalid": 0,
      "api_failed": 0,
      "energy_available": 50,
      "output_caps": 0,
      "mean_measured_wall_seconds": 11.625604221999529,
      "setup_HTTP_requests": 0
    },
    "M2/full": {
      "calls": 400,
      "scores": 400,
      "input_invalid": 0,
      "api_failed": 0,
      "energy_available": 400,
      "output_caps": 1,
      "mean_measured_wall_seconds": 12.008649311499994,
      "setup_HTTP_requests": 0
    },
    "E4/pilot": {
      "calls": 10,
      "scores": 0,
      "input_invalid": 1,
      "api_failed": 0,
      "energy_available": 10,
      "output_caps": 0,
      "mean_measured_wall_seconds": 4.33726616999993,
      "setup_HTTP_requests": 66
    },
    "E4/full": {
      "calls": 0,
      "scores": 0,
      "input_invalid": 0,
      "api_failed": 0,
      "energy_available": 0,
      "output_caps": 0,
      "mean_measured_wall_seconds": null,
      "setup_HTTP_requests": 0
    },
    "E3/pilot": {
      "calls": 0,
      "scores": 0,
      "input_invalid": 0,
      "api_failed": 0,
      "energy_available": 0,
      "output_caps": 0,
      "mean_measured_wall_seconds": null,
      "setup_HTTP_requests": 0
    },
    "R2/full": {
      "calls": 1040,
      "planned": 1040,
      "scores": 1040
    }
  },
  "details": {}
}
~~~
