# Supervisor checkpoint

Unexpected failure; recover command resumes saved state

~~~json
{
  "type": "ValueError",
  "detail": "Registration mismatch for E0"
}
~~~
