# Supervisor checkpoint

STOP: 40 isolated baselines and 100 M3 generations; scoring deferred

~~~json
{
  "e0_planned": 1968,
  "m3_planned": 240,
  "m3_finished": 100,
  "by_context_length": {
    "4000": {
      "calls": 45,
      "mean_seconds": 28.96497824444345,
      "invalid": 0,
      "output_caps": 0
    },
    "1000": {
      "calls": 55,
      "mean_seconds": 11.71832071454476,
      "invalid": 0,
      "output_caps": 1
    }
  },
  "remaining_main_service_seconds": null,
  "remaining_MAIN_call_budget": 2740,
  "remaining_MAIN_service_scenarios_seconds": [
    45808.19875785264,
    93064.04038977505
  ],
  "scenario_warning": "Rate extrapolations; future output lengths and overhead are unknown",
  "runtime_note": "Requires frozen pending counts; excludes unmeasured overhead",
  "pending_main_by_length": null,
  "isolated_baseline_calls": 40,
  "M3_scoring": "deferred"
}
~~~
