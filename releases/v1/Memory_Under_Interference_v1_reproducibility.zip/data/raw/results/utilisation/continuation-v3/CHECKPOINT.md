# Supervisor checkpoint

User pause

~~~json
{
  "reason": "stopped",
  "started_at": "2026-11-23T06:48:54.617548+00:00",
  "sensor": "LOCAL_USER_ROOT\\Downloads\\New folder\\ver10_hwf.CSV",
  "elapsed_time_cutoff": null,
  "stage": "R2",
  "phase": "full",
  "operation": "generation",
  "error": "User pause",
  "stopped_at": "2026-11-23T09:22:37.060320+00:00"
}
~~~
