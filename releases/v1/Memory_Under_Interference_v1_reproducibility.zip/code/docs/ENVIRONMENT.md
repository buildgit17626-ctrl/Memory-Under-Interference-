# Environment record — P1 revision, 2026-10-17 (Asia/Kolkata)

## Hardware and software

- Owner-provided hardware: Intel Core i5-13420H, 16 GB RAM, no discrete GPU.
- Owner-provided OS: Windows 11. Python reports kernel build 10.0.26300;
  platform.platform() says Windows-10-10.0.26300-SP0. Preserve this raw string
  when logging rather than interpreting its Windows-10 label as the product edition.
- Python: **3.13.7, 64-bit**, installed on the host and selected using `py -3.13`.
  Exact version: `3.13.7 (tags/v3.13.7:bcee1c3, Aug 14 2025, 14:15:11)
  [MSC v.1944 64 bit (AMD64)]`. Active project environment: `.venv313/`.
  The old `.venv/` and `.python311/` are retained for rollback only; they do not
  silently change interpreter when the system launcher default changes.
- Dependencies: requirements.txt pins the agreed stack plus pytest and Ruff.
  requirements-lock.txt records the fully resolved validation environment.
  The updated agreed stack is NumPy, pandas, SciPy, Matplotlib, CodeCarbon,
  psutil, pytest and Ruff. OpenML/scikit-learn were removed because the revised
  AGENTS no longer includes them. NumPy 2.2.6, SciPy 1.15.3 and Matplotlib 3.10.3
  provide Windows CPython 3.13 wheels; CodeCarbon is explicitly updated to 3.0.4.
  These are deliberate version-pin changes, not silent interpreter fallbacks.
  Final installation/import/test evidence is recorded in learning/P1.md.
  The completed Python 3.13 environment has 61 pinned resolved dependencies;
  all required packages import, pip check passes, and 129 tests pass. No required
  package failed to install. CodeCarbon's transitive pynvml import emits a
  non-fatal deprecation warning; no measurement was started.
- Python 3.13's owner-only temporary directories were inaccessible to the tool's
  restricted execution token. Validation therefore runs in a normal host process,
  as it does from the owner's PowerShell, with the worker's own Job Object limits
  still enforced. Administrator privileges are not required by the runner.
- Runtime selected for P2: local Ollama HTTP API, loopback address only. Tags:
  qwen2.5-coder:0.5b and qwen2.5-coder:1.5b. Licence checks are in REFERENCES.md.
  P1 does not download models, generate answers, or claim installed model digests.

## Power settings: observations versus run protocol

- Latest recheck on 2026-10-17, after the owner's update: **Best performance
  and AC connected confirmed**. GetSystemPowerStatus returned ACLineStatus=1;
  PowerGetEffectiveOverlayScheme returned success (0) and
  ded574b5-45a0-4f42-8737-46345c09c238. The Balanced base scheme below remains
  active; it is distinct from the Best performance overlay. This supersedes
  the earlier battery/power-saving observation, retained below as history.
- `powercfg /getactivescheme`: Balanced,
  GUID 381b4222-f694-41f0-9685-ff5bb260df2e.
- Earlier on 2026-10-17: `GetSystemPowerStatus` succeeded and returned **ACLineStatus=0
  (on battery)**. The earlier 2026-10-16 check reported ACLineStatus=1; the new
  observation supersedes it for this revision.
- In that earlier check, `PowerGetEffectiveOverlayScheme` succeeded (return code 0), reporting
  **961cc777-2547-4f9d-8174-7d86181b8a7a**, Microsoft's power-saving / Better Battery
  overlay. This is **not Best performance**. The Settings UI was not inspected.
  Best performance corresponds to ded574b5-45a0-4f42-8737-46345c09c238.
  No system settings were changed by the harness.
- Owner's required run setting: **Best performance, plugged in**, now verified.
  Recheck before each measured batch because power state can change.
- HWiNFO CPU Package Power availability: recorded in SPEC as owner-confirmed;
  logging was not started or independently verified during P1.
- Thread count, cooldown and fixed output-token cap will be registered in P2/P3
  before measured runs. No unknown setting is filled with a guessed value.

Before measured batches: verify AC, record the exact Settings power mode and
active scheme, close heavy apps, set the same thread count, use cooldown gaps,
and measure 60 seconds of idle baseline. CPU package estimates exclude memory,
display, storage and other laptop components. CodeCarbon offline is secondary.
P1 tests are correctness/resource checks, not energy measurements.

Recheck scheme with `powercfg /getactivescheme`; record the power-mode overlay
from Windows Settings > System > Power & battery. Record machine metadata,
versions, date and actual power settings with each later results file.

Overlay GUID reference: [Microsoft power slider documentation](https://learn.microsoft.com/en-us/windows-hardware/customize/desktop/customize-power-slider).

## P2 live session, 2026-10-19 (Asia/Kolkata)

Observed before the P2 smoke: Python 3.13.7, 64-bit; Windows-11-10.0.26300-SP0;
13th Gen Intel(R) Core(TM) i5-13420H; physical RAM 16,786,780,160 bytes.
GetSystemPowerStatus returned ACLineStatus=1 and the effective overlay API
returned success with ded574b5-45a0-4f42-8737-46345c09c238: Best performance.
No system settings were changed. Session metadata is recorded alongside raw data.

Ollama 0.40.6, local API at 127.0.0.1:11434. Installed model metadata:

| Model | Quantization | Local digest |
| --- | --- | --- |
| qwen2.5-coder:0.5b | Q4_K_M | 4ff64a7f502a08b7616edb8ca0a79eb1853fc363d842b7df4b46915d11a3fb09 |
| qwen2.5-coder:1.5b | Q4_K_M | d7372fd828518a4d38b1eb196c673c31a85f2ed302b3d1e406c4c2d1b64a0668 |

The manifest retains each exact runtime template, parameters, model details and
licence text. Both installed licence texts include Apache 2.0. Version pins are
unchanged from P1. Fixed requested inference options: CPU-only num_gpu=0,
num_thread=8, num_ctx=4096, num_predict=768, seed=1729, temperature=0.
The resolved cache policy is keep_alive=0 for scored runs; each request's
load_duration is preserved separately in its raw API body. HWiNFO and CodeCarbon
measurement were not started. These observations are not energy measurements.


## P3 live pilot, 2026-10-20 (Asia/Kolkata)

HWiNFO64 version 8.54-6090 was read from the owner's screenshot. Source CSV:
`LOCAL_USER_ROOT\OneDrive\Documents\Experiments\OllamaDataset.CSV`.
Observed cp1252 encoding, comma separator, decimal dot, Date `%d.%m.%Y`,
Time `%H:%M:%S.%f`, UTC+05:30, CPU Package Power [W]. Preflight confirmed append
only growth, fresh readings and approximately 501 ms median polling. The owner
set 500 ms polling and direct disk logging. One scored window had a gap >1 s;
its affected energy estimates remain missing with flags.

Session metadata confirmed Python 3.13.7 64-bit, Windows build 26300,
i5-13420H and 16,786,780,160 RAM bytes, ACLineStatus=1, Best performance.
The runner rechecked AC/mode before each scored request. Ollama 0.40.6 and both
model digests matched P2; all scored requests used keep_alive=0 and reported
zero cached prompt tokens. Scored requests ran from 00:14:15 to 01:59:35 IST.

The 60-second HWiNFO idle baseline was 15.4201366935 W. CodeCarbon 3.0.4 offline
IND machine mode used a separate 60.0163-second baseline; native CPU power was
42.5 W and RAM power 10 W both at baseline and throughout all scored requests.
Its nearly constant hardware estimate is not a useful workload-sensitive
cross-check. The full native observations are retained. No claim of measured
whole-laptop power or accurate per-phase energy follows from these logs.
