import ast
import gzip
import hashlib
import json
import random
import shutil

import pytest

from experiments.config import (
    FEW_SHOT_EXAMPLES,
    MODELS,
    PROMPTS,
    TASK_COUNT,
    TASK_IDS,
    TASK_SELECTION_SEED,
)
from prompt_energy.tasks import DATA_DIR, load_tasks


def test_registration_and_order():
    expected = tuple(
        f"HumanEval/{i}"
        for i in sorted(random.Random(TASK_SELECTION_SEED).sample(range(164), TASK_COUNT))
    )
    assert TASK_IDS == expected
    assert tuple(task.task_id for task in load_tasks()) == expected
    assert len(set(TASK_IDS)) == 40
    assert MODELS == ("qwen2.5-coder:0.5b", "qwen2.5-coder:1.5b")
    assert set(PROMPTS) == {"P0", "P1", "P2", "P3_1", "P3_3", "P4", "P5"}
    assert PROMPTS["P3_1"]["examples"] == 1
    assert PROMPTS["P3_3"]["examples"] == 3


@pytest.mark.parametrize("ids", [("HumanEval/999",), ("HumanEval/1", "HumanEval/1")])
def test_invalid_selection_fails(ids):
    with pytest.raises(ValueError):
        load_tasks(ids)


def test_corrupt_archive_fails(tmp_path):
    shutil.copy(DATA_DIR / "manifest.json", tmp_path)
    (tmp_path / "HumanEval.jsonl.gz").write_bytes(b"corrupted")
    with pytest.raises(ValueError, match="checksum"):
        load_tasks(data_dir=tmp_path)


def test_provenance():
    manifest = json.loads((DATA_DIR / "manifest.json").read_text())
    assert (
        hashlib.sha256((DATA_DIR / "HumanEval.jsonl.gz").read_bytes()).hexdigest()
        == (manifest["sha256"])
    )
    assert manifest["license"] == "MIT"
    assert "Copyright (c) OpenAI" in (DATA_DIR / "HumanEval.LICENSE").read_text()


@pytest.mark.parametrize("problem", ["duplicate", "missing", "field", "entry_point"])
def test_malformed_records_fail(tmp_path, problem):
    with gzip.open(DATA_DIR / "HumanEval.jsonl.gz", "rt", encoding="utf-8") as stream:
        rows = [json.loads(line) for line in stream]
    if problem == "duplicate":
        rows.append(rows[0])
    elif problem == "missing":
        rows.pop()
    elif problem == "field":
        rows[0]["prompt"] = 42
    else:
        rows[0]["entry_point"] = "not a Python identifier"
    archive = tmp_path / "HumanEval.jsonl.gz"
    with gzip.open(archive, "wt", encoding="utf-8") as stream:
        stream.write("\n".join(json.dumps(row) for row in rows))
    manifest = {"sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
    (tmp_path / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(ValueError):
        load_tasks(data_dir=tmp_path)


def test_demonstrations_do_not_duplicate_selected_functions():
    def signature(source):
        function = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef))
        statements = [
            n
            for n in function.body
            if not (
                isinstance(n, ast.Expr)
                and isinstance(n.value, ast.Constant)
                and isinstance(n.value.value, str)
            )
        ]
        return function.name, ast.dump(ast.Module(body=statements, type_ignores=[]))

    selected = [signature(t.reference_source) for t in load_tasks()]
    for _, solution in FEW_SHOT_EXAMPLES:
        name, body = signature(solution)
        assert name not in {s[0] for s in selected}
        assert body not in {s[1] for s in selected}


def test_allowlist_has_documented_fingerprint():
    from prompt_energy.policy import ALLOWED_IMPORTS
    from prompt_energy.worker import EXPORTS

    assert ALLOWED_IMPORTS == EXPORTS.keys()
    fingerprint = hashlib.sha256(
        json.dumps(
            {"imports": sorted(ALLOWED_IMPORTS), "exports": EXPORTS},
            sort_keys=True,
        ).encode()
    ).hexdigest()
    safety = (DATA_DIR.parent / "docs" / "SAFETY.md").read_text(encoding="utf-8")
    assert fingerprint in safety, "Document every import/export change in SAFETY.md"
